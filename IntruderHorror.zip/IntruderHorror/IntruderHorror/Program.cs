﻿using static System.Collections.Specialized.BitVector32;

string playerName;
int attemp;
bool[] Optionselection = new bool[6];
Console.WriteLine("DeivodGMG presenta:");
await Task.Delay(5000);
MenuStart();
void MenuStart()
{
    Console.Clear();
    Console.WriteLine("                            ---Intruder Horror---");
    Console.WriteLine("[1] Comenzar juego\n[2] Configuracion");
    attemp = 1;
    bool[] Optionsselection = { false, false, false, false, false, false };
    for (int i = 0; i < 6; i++)
    {
        Optionselection[i] = false;
    }
    while (true)
    {
        string selection = Console.ReadLine();
        if (selection == "1")
        {
            PlayerName();
            break;
        }
        if (selection == "2")
        {
            ConfigureTerminal();
        }
        else
        {
            Console.WriteLine("Dato Invalido");
        }
    }
}
void ConfigureTerminal()
{
    Console.Clear();
    Console.WriteLine("Ingresa alguno de estos numeros para elegir un color\n[1] Blanco\n[2] Rojo\n[3] Amarillo\n[4] Azul\n[5] Gris");
    string text = Console.ReadLine();
    Console.WriteLine("[6] Salir");
    while (true)
    {
        string selection = Console.ReadLine();
        if (selection == "6")
        {
            MenuStart();
            break;
        }
        if (selection != "1" || selection != "2" || selection != "3" || selection != "4" || selection != "5" || selection != "6")
        {
            Console.WriteLine("Ingresa 6 para regresar.");
        }
        if (selection == "1")
        {
            Console.ForegroundColor = ConsoleColor.White;
        }
        if (selection == "2")
        {
            Console.ForegroundColor = ConsoleColor.Red;
        }
        if (selection == "3")
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
        }
        if (selection == "4")
        {
            Console.ForegroundColor = ConsoleColor.Blue;
        }
        if (selection == "5")
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
        }
    }
}
void PlayerName()
{
    Console.Clear();
    Console.WriteLine("--Ingresa tu nombre:--");
    string data = Console.ReadLine();
    playerName = data;
    Console.WriteLine(playerName);
    Message();
}
void Message()
{
    Console.Clear();
    Console.WriteLine("5/12/2024 Terminaste de cenar y te fuiste a la \ncama para dormir, cuando de la nada recibes una llamada \nde tu telefono,contestas, pero no logras \nidentificar a la persona, pero te amenazo diciendote \nque entrara a por ti. Cuidadosamente te diriges a una ventana \npara mirar al exterior... te das cuenta de que no estas solo.\nTienes poco tiempo de preparacion para lo peor.");
    Console.WriteLine("---------------------------------------------------------------");
    Console.WriteLine("[y] Empezar");
    while (true)
    {
        string text = Console.ReadLine();
        if (text == "y")
        {
            Game();
            break;
        }
        else
        {
            Console.WriteLine("Ingresa y para jugar.");
        }
    }
}
void Game()
{ 
    //Diseño del mapa
    Console.Clear();
        Console.WriteLine("|                             |        Jugador: " + playerName + "          Movimientos disponibles: " + attemp + "\n|                             |\n|                             |\n|             [ ]             | [1] Asegurar la puerta principal          [4] Activar alarma antirobos\n|                             | [2] Encerrarte en tu habitacion           [5] Bloquear la puerta trasera\n|                             | [3] Asegurar la ventana                   [6] Esconderse\n|                             |\n|_____________________________|");
        while (true)
    {
        string text = Console.ReadLine();
        int selection = Convert.ToInt32(text);
        if (selection >= 1 && selection <= 6)
        {
            attemp--;
            selection--;
            Optionselection[selection] = true;
            if (attemp > 0)
            {
                Game();
            } //Vuelve a llamar la funcion
            if (attemp <= 0)
            {
              EndGame();
                break;
        }
        if (selection < 1 || selection > 6)
        {
            Console.WriteLine("Opcion invalida.");
        }
        }
    }
}
void EndGame()
{
    Console.Clear();
    if (Optionselection[3] == true) //GG
    {
        Console.WriteLine("                                       ¡Felicidades! Has ganado :)\nEl intruso rompio la ventana y entro,\npero eso provoco que sonara la alarma que instalaste.\nDesesperadamente el intruso empieza a buscarte...\npero le gano la angustia\nde ser atrapado, asi que el intruso huyo lejos de tu \nvivienda.");
        Exit();
    } //You Win
    if (Optionselection[0] == true) //Asegurar puerta principal
    {
        Console.WriteLine(" ¡Perdiste! El intruso te atrapo :(\nLa puerta estaba asegurada, \npero el intruso no sabia forzar cerraduras\nasi que logro entrar por la ventana.\nClaramente te encontro :(.");
        Exit();
    }
    if (Optionselection[1] == true) //Encerrarte en tu cuarto
    {
        Console.WriteLine(" ¡Perdiste! El intruso te atrapo :(\nTe encerraste en tu cuarto, \npero el intruso tumbo la puerta de tu habitacion\n y obvio, te encontro :(.");
        Exit();
    }
    if (Optionselection[2] == true) //Asegurar ventanas
    {
        Console.WriteLine(" ¡Perdiste! El intruso te atrapo :(\nBloqueaste la unica ventana, \npero el intruso logro entrar por la\npuerta trasera y claro, te encontro :(.");
        Exit();
    }
    if (Optionselection[4] == true) //Bloquear puerta trasera
    {
        Console.WriteLine(" ¡Perdiste! El intruso te atrapo :(\nLa puerta trasera estaba aseguradada, \npero el intruso logro entrar por la\nventana, luego te vio asustado y te\natrapo:(.");
        Exit();
    }
    if (Optionselection[5] == true) //Esconderrse
    {
        Console.WriteLine(" ¡Perdiste! El intruso te atrapo :(\nA pesar de que habias escondido, \nel intruso tuvo toda la paciencia del mundo\npara buscarte y\nal final te encontro :(.");
        Exit();
    }
} //La funcion
void Exit()
{
    Console.WriteLine("[3] Ir al menu");
    while (true)
    {
        string tex = Console.ReadLine();
        int menu = Convert.ToInt32(tex);
        if (menu == 3)
        {
            MenuStart();
            break;
        }
        else
        {
            Console.WriteLine("Opcion Invalida");
        }
    }
}